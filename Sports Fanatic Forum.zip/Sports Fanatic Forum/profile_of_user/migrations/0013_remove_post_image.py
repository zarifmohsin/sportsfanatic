

from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('profile_of_user', '0012_profile'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='post',
            name='image',
        ),
    ]
