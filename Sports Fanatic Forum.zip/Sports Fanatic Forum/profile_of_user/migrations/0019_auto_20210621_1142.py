

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('profile_of_user', '0018_auto_20210621_1138'),
    ]

    operations = [
        migrations.AlterField(
            model_name='profile',
            name='image',
            field=models.ImageField(default='/media/images/user_oSrbhDM.png', upload_to='images'),
        ),
    ]
