

from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('profile_of_user', '0008_replie'),
    ]

    operations = [
        migrations.AddField(
            model_name='replie',
            name='post',
            field=models.ForeignKey(default='', on_delete=django.db.models.deletion.CASCADE, to='profile_of_user.post'),
        ),
    ]
